import{_ as s,c as t,o as r,a as o}from"./index-DvmcH8By.js";const a={name:"Review_history"};function n(i,e,c,l,f,p){return r(),t("div",null,[...e[0]||(e[0]=[o("h2",null,"History of Reviews",-1),o("p",null,"Use this tool to see a history of reviews and feedback.",-1)])])}const _=s(a,[["render",n]]);export{_ as default};
//# sourceMappingURL=ReviewHistory-DeeL1NGI.js.map
