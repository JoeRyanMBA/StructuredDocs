import{_ as r,c as s,o as e,a as t}from"./index-DvmcH8By.js";const n={name:"Author History"};function a(i,o,c,l,u,p){return e(),s("div",null,[...o[0]||(o[0]=[t("h2",null,"Author History",-1),t("p",null,"Use this tool to view author actions history.",-1)])])}const d=r(n,[["render",a]]);export{d as default};
//# sourceMappingURL=AuthorHistory-DZJsERSu.js.map
