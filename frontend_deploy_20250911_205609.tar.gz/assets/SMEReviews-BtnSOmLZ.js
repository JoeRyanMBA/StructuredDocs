import{_ as o,c as s,o as n,a as t}from"./index-DvmcH8By.js";const r={name:"SME Review"};function a(c,e,i,l,p,d){return n(),s("div",null,[...e[0]||(e[0]=[t("h2",null,"Subject-Matter Expert (SME) Reviews",-1),t("p",null,"Use this tool to send topics to SMEs for review and feedback.",-1)])])}const u=o(r,[["render",a]]);export{u as default};
//# sourceMappingURL=SMEReviews-BtnSOmLZ.js.map
